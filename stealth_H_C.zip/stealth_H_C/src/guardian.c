#include "../include/guardian.h"

Guardian init_guardian(int x, int y, int vision) {
    Guardian guardian;

    guardian.x = x;
    guardian.y = y;
    guardian.vision = vision;
    guardian.speed = SPEED;
    guardian.direction = rand() % 4;
    return guardian;
}

int guard_forward(Guardian * guardian,int panic) {

    switch (guardian -> direction) {
    case UP:
		if (panic == 0)
			guardian -> y -= (1.0 / 60) * guardian -> speed;
		else {
			guardian -> y -= (1.0 / 60) * SPEED;
		}	
        break;

    case LEFT:
		if (panic == 0)
			guardian -> x -= (1.0 / 60) * guardian -> speed;
        else {
			guardian -> x -= (1.0 / 60) * SPEED;
		}	
        break;

    case DOWN:
		if (panic == 0)
			guardian -> y += (1.0 / 60) * guardian -> speed;
        else {
			guardian -> y += (1.0 / 60) * SPEED;
		}	
        break;

    case RIGHT:
		if (panic == 0)
			guardian -> x += (1.0 / 60) * guardian -> speed;
        else {
			guardian -> x += (1.0 / 60) * SPEED ;
		}	
        break;

    case NEUTRAL:
        break;
    }
    return 0;
}

void new_guard_speed(Guardian * guardian) {
    int random_speed;
    random_speed = (rand() % 50) + 30;
    guardian -> speed = (((float) random_speed) / 100) * SPEED;
}

void guardian_random_direction(Guardian * guardian) {
	int random;
	random = rand() % 50;
	if (random == 1) {
		guardian->direction = rand() % 3;
	}
}
