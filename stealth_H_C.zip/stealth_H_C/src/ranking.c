#include "../include/ranking.h"

int compare_mana_player_ascending(const void *a, const void *b){
    Player_info *p1 = (Player_info *)a;
    Player_info *p2 = (Player_info *)b;
    return p2->mana_score - p1->mana_score;
}

int compare_mana_player_descending(const void *a, const void *b){
    Player_info *p1 = (Player_info *)a;
    Player_info *p2 = (Player_info *)b;
    return p1->mana_score - p2->mana_score;
}

int compare_time_player_ascending(const void *a, const void *b){
    Player_info *p1 = (Player_info *)a;
    Player_info *p2 = (Player_info *)b;
    return p2->time_score - p1->time_score;
}

int compare_time_player_descending(const void *a, const void *b){
    Player_info *p1 = (Player_info *)a;
    Player_info *p2 = (Player_info *)b;
    return p1->time_score - p2->time_score;
}


Player_info * loadRanking(int * nbr_players){
    FILE * ranking_file;
    Player_info * players_info;
    int i;
    /* Opening file */
    ranking_file = fopen("./etc/ranking.bin", "rb");
    if (NULL == ranking_file){
        printf("Error opening reading file\n");
        return NULL;
    }
    /* Reading first int which indicate the number of saved players in ranking */
    fread(nbr_players, sizeof(int), 1, ranking_file);
    /* Allocate memory for ranking array */
    players_info = (Player_info *) malloc(sizeof(Player_info) * (*nbr_players));
    if (NULL == players_info){
        printf("Error memory allocate for players info\n");
        fclose(ranking_file);
        return NULL;
    }
    /* Reading */
    for (i = 0; i < *nbr_players; i++){
        fread(&(players_info[i]), sizeof(Player_info), 1, ranking_file);
    }
    /* Closing file */
    fclose(ranking_file);
    return players_info;
}

int savePlayerScore(const char * name, int age, int time_score, int mana_score){
    Player_info * players_info, player;
    int nbr_players, i, error_state;
    /* Fill the Player struct */
    strcpy(player.name, name);
    player.age = age;
    player.time_score = time_score;
    player.mana_score = mana_score;
    /* Loading rank */
    if (NULL == (players_info = loadRanking(&nbr_players))){
        printf("This error is from the saveRanking function\n");
        return 1;
    }
    
    /* We will read the file and check if this player is already in the rank */
    if (nbr_players > 0){
        for (i = 0; i < nbr_players; i++){
            /* Player founded */
            if (strcmp(players_info[i].name, player.name) == 0){
                /* If there is a new personal high score for this player */
                if (player.time_score < players_info[i].time_score || player.mana_score < players_info[i].mana_score){
                    /* If the time score is better */
                    if (player.time_score < players_info[i].time_score){
                        players_info[i].time_score = player.time_score;
                    }
                    /* If the mana score is better */
                    if (player.mana_score < players_info[i].mana_score){
                        players_info[i].mana_score = player.mana_score;
                    }
                    /* We changed values and we overwrite all informations on the file */
                    error_state = saveRanking(players_info, nbr_players);
                    free(players_info);
                    return error_state;
                }
                /* If no new change, no need to write anything new in the file, so we exit the function */
                else{
                    free(players_info);
                    return 0;
                }
            }
        }
    }

    /* Player unfounded or no player saved in the file --> We add the new player */
    nbr_players++;
    players_info = (Player_info *) realloc(players_info, nbr_players * sizeof(Player_info));
    players_info[nbr_players - 1] = player;
    error_state = saveRanking(players_info, nbr_players);
    free(players_info);
    return error_state;
}


int saveRanking(Player_info * players_info, int nbr_players){
    FILE * ranking_file;
    int i;
    /* Opening file */
    ranking_file = fopen("./etc/ranking.bin", "wb+");
    if (NULL == ranking_file){
        printf("Error opening writting file\n");
        return 1;
    }

    /* We move the pointer at the start of the file to overwrite the whole file */
    fseek(ranking_file, 0, SEEK_SET);

    /* Now we write the number of players and then the data from the array of struct Player_info */
    fwrite(&nbr_players, sizeof(int), 1, ranking_file);

    for (i = 0; i < nbr_players; i++){
        fwrite(&players_info[i], sizeof(Player_info), 1, ranking_file);
    }

    /* Closing file */
    fclose(ranking_file);
    return 0;
}

int switch_ranking_sorting_mode(int sorting_mode, int new_choice){
    /* Nothing was sorted */
    if (sorting_mode == 0)
        return new_choice;
    /* Sorted by time or mana score again */
    if (new_choice == abs(sorting_mode))
        return -sorting_mode;

    return new_choice;
}

