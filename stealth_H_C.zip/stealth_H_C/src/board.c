/*
File : board.c
Name : Rajon Lionel
16/11/22
*/

#include "../include/board.h"

void algo_generate_random_walls(Board * board, int minside, int x, int y, int x_start, int y_start){
	
	int i, size_part_1, startwall, endwall;

	/* Rule 1 */
	if (x <= y){
		/* Rule 2 and 3 */
		if ((y < (2 * minside) + 1) || ((y < 4 * minside) && (rand()%2 == 0))){
			return;
		}

		/* Rule 4 */
		do{
			size_part_1 = rand()%y;
		}while(y - size_part_1 - 1 < minside || size_part_1 < minside);
		if (rand()%2 == 0){
			startwall = x_start + 3;
			endwall = x_start + x - 1;
			board->floor[x_start][y_start + size_part_1].type = WALL_OPENING;
			board->floor[x_start + 1][y_start + size_part_1].type = WALL_OPENING;
			board->floor[x_start + 2][y_start + size_part_1].type = WALL_OPENING;
		}
		else{
			startwall = x_start;
			endwall = x_start + x - 4;
			board->floor[x_start + x - 3][y_start + size_part_1].type = WALL_OPENING;
			board->floor[x_start + x - 2][y_start + size_part_1].type = WALL_OPENING;
			board->floor[x_start + x - 1][y_start + size_part_1].type = WALL_OPENING;
		}

		for (i = startwall; i <= endwall; i++){
			(board->floor[i][y_start + size_part_1]).type = WALL;
		}
		/* Rule 5  - Recursivity */
		algo_generate_random_walls(board, minside, x, size_part_1, x_start, y_start);
		algo_generate_random_walls(board, minside, x, y - size_part_1 - 1, x_start, y_start + size_part_1 + 1);
	}else{
		srand(time(NULL));
		/* Rule 2 and 3 */
		if ((x < (2 * minside) + 1) || ((x < 4 * minside) && (rand()%2 == 0))){
			return;
		}

		/* Rule 4 */
		do{
			size_part_1 = rand()%x;
		}while(x - size_part_1 - 1 < minside || size_part_1 < minside);
		if (rand()%2 == 0){
			startwall = y_start + 3;
			endwall = y_start + y;
			board->floor[x_start + size_part_1][y_start].type = WALL_OPENING;
			board->floor[x_start + size_part_1][y_start + 1].type = WALL_OPENING;
			board->floor[x_start + size_part_1][y_start + 2].type = WALL_OPENING;
		}
		else{
			startwall = y_start;
			endwall = y_start + y - 4;
			board->floor[x_start + size_part_1][y_start + y - 3].type = WALL_OPENING;
			board->floor[x_start + size_part_1][y_start + y - 2].type = WALL_OPENING;
			board->floor[x_start + size_part_1][y_start + y - 1].type = WALL_OPENING;
		}

		for (i = startwall; i <= endwall; i++){
			(board->floor[x_start + size_part_1][i]).type = WALL;
		}
		/* Rule 5  - Recursivity */
		algo_generate_random_walls(board, minside, size_part_1, y, x_start, y_start);
		algo_generate_random_walls(board, minside, x - size_part_1 - 1, y, x_start + size_part_1 + 1, y_start);
	}
}

void check_generate_random_coord_guardian_relics(Board board, int * rand_x, int * rand_y){
	do{
		*rand_x = rand()%(WIDTH - 2) + 1;
		*rand_y = rand()%(HEIGHT - 2) + 1;
	}while(euclidean_distance(*rand_x, *rand_y, 1, 1) <= 20 || board.floor[*rand_x][*rand_y].type != MANA);
}

Board init_board() {
	Board board;
	int i, j;
	
	board.player = init_player(2,2,0);
    for(i = 0; i < HEIGHT; i++) {
        for(j = 0; j < WIDTH; j++) {
        	board.floor[j][i]= init_cell(MANA, i, j);
        }
    }
	init_walls(&board, 9);
	board.relics_number = 3;
	board.unstolen_relics_number = board.relics_number;
	board.relics = init_relics_list(&board);
	board.guardians_number = 5;
	board.guardians = init_guardians(board);
	board.panic = 0;
	return board;
}

Guardian * init_guardians(Board board){
	Guardian * guardians;
	int i, vision, rand_x, rand_y;
	guardians = (Guardian *) malloc(board.guardians_number * sizeof(Guardian));
	assert(NULL != guardians);
	vision = 4;
	for (i = 0; i < board.guardians_number; i++){
		check_generate_random_coord_guardian_relics(board, &rand_x, &rand_y);
		guardians[i] = init_guardian(rand_x, rand_y, vision);
	}
	return guardians;
}


Cell init_relic(int x, int y){
	Cell relic;
	relic.x = x;
	relic.y = y;
	relic.type = RELIC;
	return relic;
}

Cell * init_relics_list(Board * board){
	Cell * relics;
	int i, rand_x, rand_y;
	relics = (Cell *) malloc(board->relics_number * sizeof(Cell));
	assert(NULL != relics);
	for (i = 0; i < board->relics_number; i++){
		check_generate_random_coord_guardian_relics(* board, &rand_x, &rand_y);
		relics[i] = init_relic(rand_x, rand_y);
		board->floor[rand_x][rand_y].type = RELIC;
	}
	return relics;
}

void init_walls(Board * board, int minside) {
    int i;
    /* Board limits */
    for (i = 0; i < HEIGHT; i++) {
        (board -> floor[0][i]).type = WALL;
        (board -> floor[WIDTH - 1][i]).type = WALL;
    }
    for (i = 0; i <= WIDTH; i++) {
        (board -> floor[i][0]).type = WALL;
        (board -> floor[i][HEIGHT - 1]).type = WALL;
    }
    /* Setting seed here for the call of algo_generate_random_walls() because this function is recursive, and we have to set it just once. */
    srand(time(NULL));
    algo_generate_random_walls(board, minside, WIDTH - 2, HEIGHT - 2, 1, 1);
}

void remove_relic(Board * board, int index){
	int i;
	if (index < 0 || index >= board->relics_number){
		printf("Index hors limite dans remove_relic\n");
		exit(1);
	}
	/* Change the cell on board floor */
	board->floor[board->relics[index].x][board->relics[index].y].type = ROOM;
	/* To remove a relic, we have to shift relics to the left */
    for (i = index; i < board->relics_number - 1; i++) {
        board->relics[i] = board->relics[i + 1];
    }

    /* Reallocate memory */
    board->relics = (Cell *)realloc(board->relics, (board->relics_number - 1) * sizeof(Cell));
    board->relics_number --;
}
