#include "../include/music_sounds.h"

void play_main_music(){
	MLV_Music * main_music;

	main_music = MLV_load_music("etc/sounds/main_theme.mp3");
	if (NULL == main_music){
		printf("Musique non trouvée ou non valide\n");
		exit(1);
	}
	MLV_play_music(main_music, 1.0, -1);
}

void play_winning_song(){
	MLV_Music * win_music;

	win_music = MLV_load_music("etc/sounds/win.mp3");
	if (NULL == win_music){
		printf("Musique non trouvée ou non valide\n");
		exit(1);
	}
	MLV_play_music(win_music, 1.0, -1);
}

void play_alarm_music(){
	MLV_Music * alarm_music;

	alarm_music = MLV_load_music("etc/sounds/alarm.mp3");
	if (NULL == alarm_music){
		printf("Musique non trouvée ou non valide\n");
		exit(1);
	}
	MLV_play_music(alarm_music, 1.0, -1);
}

void play_death_sound(){
	MLV_Sound * death_sound;

	death_sound = MLV_load_sound("etc/sounds/wasted.ogg");
	if (NULL == death_sound){
		printf("Audio non trouvé ou non valide\n");
		exit(1);
	}
	MLV_play_sound(death_sound, 0.9);
}

void play_mana_sound(){
	MLV_Sound * mana_sound;

	mana_sound = MLV_load_sound("etc/sounds/mana.ogg");
	if (NULL == mana_sound){
		printf("Audio non trouvé ou non valide\n");
		exit(1);
	}
	MLV_play_sound(mana_sound, 0.25);
}