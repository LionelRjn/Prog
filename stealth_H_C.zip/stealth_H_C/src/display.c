#include "../include/display.h"

MLV_Color color_depending_choice_and_number(int choice, int n, MLV_Color background_color){
    if (choice == n)
        return MLV_COLOR_WHITE;
    else
        return background_color;
}

void display_board(Board board, Display_settings settings, double time) {
    MLV_Image * front_door_img;
    int i, j;
    /* Whole board */
    MLV_clear_window(MLV_COLOR_BLACK);
    for (i = 0; i < HEIGHT; i++) {
        for (j = 0; j < WIDTH; j++) {
            display_cell_board(settings, board.floor[j][i], board.panic);
        }
    }
    /* Guardians */
    display_guardians(board, settings);
    /* Door */
    front_door_img = MLV_load_image("./etc/img/front_door.png");
    MLV_resize_image(front_door_img, settings.scale * 2, settings.scale * 2);
    MLV_draw_image(front_door_img, settings.scale, settings.scale);

    /* Character */
    display_player(board, settings);

    /* Infos */
    display_info_in_game(board, settings, time);

    MLV_actualise_window();

    /* Free image */
    MLV_free_image(front_door_img);
}

void display_cell_board(Display_settings settings, Cell cell, int panic) {
    MLV_Color background_color;

    if (panic >= 1 && (panic%4 == 0 || panic%4 == 2))
        background_color = MLV_COLOR_RED;
    else
        background_color = settings.background_color;

    switch(cell.type){            
        case WALL_OPENING:
            MLV_draw_filled_rectangle(cell.y * settings.scale, cell.x * settings.scale, settings.scale - 1 ,  settings.scale - 1, background_color);
            break;
        case WALL:
            MLV_draw_filled_rectangle(cell.y * settings.scale, cell.x * settings.scale, settings.scale - 1 ,  settings.scale - 1, settings.wall_color);
            break;
        case ROOM:
            MLV_draw_filled_rectangle(cell.y * settings.scale, cell.x * settings.scale, settings.scale - 1 , settings.scale - 1, background_color);
                                break;
        case MANA:
            MLV_draw_filled_rectangle(cell.y * settings.scale, cell.x * settings.scale, settings.scale - 1 , settings.scale - 1, background_color);
            MLV_draw_filled_circle(cell.y * settings.scale + (settings.scale/2), cell.x * settings.scale + (settings.scale/2), settings.scale/4, MLV_rgba(0,255,255,255));
            break;
        case RELIC:
            MLV_draw_filled_rectangle(cell.y * settings.scale, cell.x * settings.scale, settings.scale - 1 ,  settings.scale - 1, settings.relic_color);
            /*MLV_draw_filled_circle(cell.y * settings.scale + settings.scale /2, cell.x * settings.scale + settings.scale /2,  settings.scale /4, settings.relic_color);*/
            break;
        case OLD_RELIC :  
            MLV_draw_filled_rectangle(cell.y * settings.scale, cell.x * settings.scale, settings.scale - 1 , settings.scale - 1, background_color);
            break;
    }
}

void display_death_screen(Display_settings settings){
    /* To synchronize with sound */
    MLV_wait_seconds(1);
    /* Draw image */
    set_and_draw_image("etc/img/wasted.png", 0, 0, settings.width, settings.height);
    MLV_actualise_window();
    MLV_wait_seconds(4);
}

void display_guardians(Board board, Display_settings settings) {
    int i;
    for (i = 0; i < board.guardians_number; i++){
        MLV_draw_filled_circle(board.guardians[i].x * settings.scale , board.guardians[i].y * settings.scale , settings.scale/2, settings.guardian_color);
        MLV_draw_circle(board.guardians[i].x * settings.scale , board.guardians[i].y * settings.scale , settings.scale * (board.guardians[i].vision)  + + (SCALE / 2), settings.guardian_color);
    }
}

void display_info_in_game(Board board, Display_settings settings, double time){
    char str_time[20], str_mana[20], str_relics[30];
    /* Time */
    if (settings.langage == 'f')
        sprintf(str_time, "Temps : %0.2fs", time);
    else
        sprintf(str_time, "Time : %0.2fs", time);
    MLV_draw_text_box(WIDTH * settings.scale, 0, settings.width / 4, settings.scale * HEIGHT / 5, str_time
        , 0, MLV_COLOR_BLACK, MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
    /* Mana */
    sprintf(str_mana, "Mana : %d", board.player.mana);
    MLV_draw_text_box(WIDTH * settings.scale, settings.scale * HEIGHT / 5, settings.width / 4, settings.scale * HEIGHT / 5, str_mana
        , 0, MLV_COLOR_BLACK, MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
    /* Number of relics to search */
    if (settings.langage == 'f')
        sprintf(str_relics, "Reliques restantes : %d", board.unstolen_relics_number);
    else
        sprintf(str_relics, "Remaining relics : %d", board.unstolen_relics_number);
    MLV_draw_text_box(WIDTH * settings.scale, 2 * settings.scale * HEIGHT / 5, settings.width / 4, settings.scale * HEIGHT / 5, str_relics
        , 0, MLV_COLOR_BLACK, MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
}

void display_menu(Display_settings settings, int choice){
    MLV_Font * title_font, * option_font;

    MLV_clear_window(MLV_COLOR_SLATE_GREY);
    title_font = MLV_load_font("./etc/fonts/MOLIKA.ttf", settings.width/4);
    option_font = MLV_load_font("./etc/fonts/MOLIKA.ttf", settings.width/24);
    /* Title of the game */
    MLV_draw_text_with_font(settings.width/4, settings.height/4 - settings.height/20 - settings.height/7, "Stealth",
     title_font, MLV_COLOR_BLACK);

    /* Box to start a new game */

    MLV_draw_text_box_with_font(settings.width / 3, settings.height / 2, settings.width / 3, settings.height / 5, "Start a new game", option_font, 0,
     color_depending_choice_and_number(choice, 1, MLV_COLOR_SLATE_GREY), MLV_COLOR_BLACK, MLV_COLOR_SLATE_GREY, MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);

    /* Box to see rank */

    MLV_draw_text_box_with_font(settings.width / 3, settings.height / 2 + settings.height / 5, settings.width / 3, settings.height / 5, "Display ranking", option_font, 0,
     color_depending_choice_and_number(choice, 2, MLV_COLOR_SLATE_GREY), MLV_COLOR_BLACK, MLV_COLOR_SLATE_GREY, MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);

    /* Settings */
    set_and_draw_image("etc/img/settings.png", settings.width - 50, 10, 40, 40);

    MLV_actualise_window();

    MLV_free_font(title_font);
}

void display_option_settings(Display_settings settings, char * fr_str, char * en_str, int int_to_print, int choice, int number_option, int y){
    char str_tmp[20];
    if (settings.langage == 'f')
        sprintf(str_tmp, "%s %d", fr_str, int_to_print);
        
    else
        sprintf(str_tmp, "%s %d", en_str, int_to_print);

    MLV_draw_text_box(settings.width / 4, y, settings.width / 2, settings.height / 10, str_tmp, 0, 
        color_depending_choice_and_number(choice, number_option, MLV_COLOR_BLACK), MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
}

void display_player(Board board, Display_settings settings) {
    if (board.player.invisible == 1) {
        MLV_draw_filled_circle(board.player.x * settings.scale , board.player.y * settings.scale , settings.scale/2, settings.background_color);
    }
    else {
        MLV_draw_filled_circle(board.player.x * settings.scale , board.player.y * settings.scale , settings.scale/2, settings.player_color);
    }  
}

void display_ranking_screen(Player_info * players_info, Display_settings settings, int nbr_players, int sorting_mode){
    int i;
    char int_to_str[100], * keys[] = {"Nom/Name", "Age", "Temps/Time score", "Mana score"};
    
    /* Background */
    MLV_clear_window(MLV_COLOR_WHITE);

    /* Title (ranking) */
    MLV_draw_text_box(settings.width/3, settings.height/4 - settings.height/20 - settings.height/7 , settings.width/3, settings.height/ 10, "RANKING", 0, MLV_COLOR_BLACK, MLV_COLOR_WHITE, MLV_COLOR_BLACK,
            MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
    
    /* Keys of array (name and age) */
    for (i = 0; i < 2; i++){
        MLV_draw_text_box((i+1) * settings.width/6, settings.height/4 - settings.height/20 , settings.width/6, settings.height/20, keys[i], 0, MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_COLOR_GREY,
            MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
    }

    /* Keys of array (time and mana) */
    for (i = 2; i < 4; i++){
        if (sorting_mode == i - 1 || sorting_mode == -(i - 1)){
            if (sorting_mode == i - 1)
                MLV_draw_text_box((i+1) * settings.width/6, settings.height/4 - settings.height/20 , settings.width/6, settings.height/20, keys[i], 0, MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_COLOR_GREEN,
                    MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
            if (sorting_mode == -(i - 1))
                MLV_draw_text_box((i+1) * settings.width/6, settings.height/4 - settings.height/20 , settings.width/6, settings.height/20, keys[i], 0, MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_COLOR_RED,
                        MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
        }   
        else
            MLV_draw_text_box((i+1) * settings.width/6, settings.height/4 - settings.height/20 , settings.width/6, settings.height/20, keys[i], 0, MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_COLOR_GREY,
                MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
    }
    /* Infos players */
    for (i = 0; i < nbr_players; i++){
        MLV_draw_text_box(settings.width/6, settings.height/4 + i * settings.height/30 , settings.width/6, settings.height/30, players_info[i].name, 0, MLV_COLOR_WHITE, MLV_COLOR_WHITE, MLV_COLOR_BLACK,
            MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
        sprintf(int_to_str, "%d", players_info[i].age);
        MLV_draw_text_box(settings.width/3, settings.height/4 + i * settings.height/30 , settings.width/6, settings.height/30, int_to_str, 0, MLV_COLOR_WHITE, MLV_COLOR_WHITE, MLV_COLOR_BLACK,
            MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
        sprintf(int_to_str, "%d", players_info[i].time_score);
        MLV_draw_text_box(settings.width/2, settings.height/4 + i * settings.height/30 , settings.width/6, settings.height/30, int_to_str, 0, MLV_COLOR_WHITE, MLV_COLOR_WHITE, MLV_COLOR_BLACK,
            MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
        sprintf(int_to_str, "%d", players_info[i].mana_score);
        MLV_draw_text_box(2*settings.width/3, settings.height/4 + i * settings.height/30 , settings.width/6, settings.height/30, int_to_str, 0, MLV_COLOR_WHITE, MLV_COLOR_WHITE, MLV_COLOR_BLACK,
            MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
    }
    /* Settings */
    set_and_draw_image("etc/img/settings.png", settings.width - 50, 10, 40, 40);

    /* Exit cross */
    set_and_draw_image("etc/img/exit.png", 10, 10, 40, 40);
    MLV_actualise_window();
}

void display_settings(Display_settings settings, int choice){
    MLV_clear_window(MLV_COLOR_BLACK);

    /* Langage */
    set_and_draw_image("etc/img/france.png", 0, 0, 40, 40);
    set_and_draw_image("etc/img/england.png", 50, 0, 40, 40);

    /* Title (settings) */
    if (settings.langage == 'f')
        MLV_draw_text_box(settings.width / 4, settings.height / 10, settings.width / 2, settings.height / 10, "PARAMÈTRES", 0, MLV_COLOR_BLACK, MLV_COLOR_WHITE, MLV_COLOR_BLACK,
            MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);
    else
        MLV_draw_text_box(settings.width / 4, settings.height / 10, settings.width / 2, settings.height / 10, "SETTINGS", 0, MLV_COLOR_BLACK, MLV_COLOR_WHITE, MLV_COLOR_BLACK,
            MLV_TEXT_CENTER, MLV_HORIZONTAL_CENTER, MLV_VERTICAL_CENTER);

    /* Width of the window */

    display_option_settings(settings, "Largeur :", "Width :", settings.width, choice, 1, settings.height / 5);   

    /* Height of the window */

    display_option_settings(settings, "Hauteur :", "Height :", settings.height, choice, 2, 3 * settings.height / 10);
    
    /* Exit cross */
    set_and_draw_image("etc/img/exit.png", settings.width - 50, 10, 40, 40);
    /* Actualizes graphic */
    MLV_actualise_window();
}

void init_settings(Display_settings * settings){
    settings->langage = 'f';
    settings->width = MLV_get_window_width();
    settings->height = MLV_get_window_height();
    settings->scale = (settings->width)*3/4/WIDTH;
    settings->player_color = MLV_COLOR_RED;
    settings->guardian_color = MLV_COLOR_BLUE;
    settings->wall_color = MLV_COLOR_BLACK;
    settings->relic_color = MLV_COLOR_BROWN;
    settings->background_color = MLV_COLOR_SLATE_GREY;
}

void save_name_age_player(Display_settings settings, char ** name, int * age){
    char * str_age;
    MLV_clear_window(MLV_COLOR_SLATE_GREY);
    MLV_wait_input_box(0, 0, settings.width, settings.height / 2, MLV_COLOR_WHITE, MLV_COLOR_WHITE, MLV_COLOR_SLATE_GREY, "Entrez votre nom : ", name);
    MLV_wait_input_box(0, 0, settings.width, settings.height / 2, MLV_COLOR_WHITE, MLV_COLOR_WHITE, MLV_COLOR_SLATE_GREY, "Entrez votre âge : ", &str_age);
    *age = atoi(str_age);
    MLV_actualise_window();
}

void set_and_draw_image(const char * path, int x, int y, int width, int height){
    MLV_Image * img;
    /* Load/set image */
    img = set_image(path, width, height);
    /* Draw */
    MLV_draw_image(img, x, y);
    /* Free image */
    MLV_free_image(img);
}

MLV_Image * set_image(const char * path, int width, int height){
    MLV_Image * img;
    if (NULL == (img = MLV_load_image(path))){
        printf("Image %s non trouvée\n", path);
        exit(0);
    }
    MLV_resize_image_with_proportions(img, width, height);
    return img;
}

