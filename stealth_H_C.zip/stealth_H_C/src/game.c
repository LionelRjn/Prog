#include "../include/game.h"

int all_guard_forward(Board * board) {
    int i;
    for (i = 0; i < board -> guardians_number; i++) {
        change_direction(*board, &(board -> guardians[i]));
        guard_forward(&(board -> guardians[i]),board->panic);
    }
    return 0;
}

int change_direction(Board board, Guardian * guardian) {
    switch (check_colli(board, *guardian)) {
        case 0:
            break;

        case 1:
            guardian -> direction = DOWN;
            break;

        case 2:
            guardian -> direction = RIGHT;
            break;

        case 3:
            guardian -> direction = UP;
            break;

        case 4:
            guardian -> direction = LEFT;
            break;

    }
    return 0;
}

int euclidean_distance(int x1, int y1, int x2, int y2) {
    int dx = x1 - x2;
    int dy = y1 - y2;
    return (int)sqrt((double)(dx*dx + dy*dy));
}

int is_game_over(Board board){
    if (board.unstolen_relics_number == 0 && ((int) board.player.x == 1 || (int) board.player.x == 2) && ((int) board.player.y == 1 || (int) board.player.y == 2)){
        return 1;
    }
    return 0;
}

int guardians_move_and_detect(Board * board) {
    double old_guard_X, old_guard_Y;
    int i, index_relic;

    for (i = 0; i < board->guardians_number; i++) {
        old_guard_X = board->guardians[i].x;
        old_guard_Y = board->guardians[i].y;
        change_direction(*board, &board->guardians[i]);
        guard_forward(&board->guardians[i],board->panic);
        guardian_random_direction(&board->guardians[i]);
        if ((int) old_guard_X != (int) board->guardians[i].x || (int) old_guard_Y != (int) board->guardians[i].y) {
            new_guard_speed(&board->guardians[i]);
        }
        if (guardian_detect_player(*board, board->guardians[i]) == 1) {
            return 1;
        }
        if (guardian_detect_relic(*board, board->guardians[i], &index_relic) == 1) {
             board->panic = 30;
            remove_relic(board, index_relic);
            panic_mode_start(board);
		}
    }
    return 0;
}

void mana_spawning(Board * board) {
    int i, j;
    i = rand() % HEIGHT;
    j = rand() % WIDTH;
    while(board->floor[j][i].type != ROOM) {
        i = rand() % HEIGHT;
        j = rand() % WIDTH;
    }
    board->floor[j][i].type = MANA;
}

int move(Board * board, Direction direction) {
    double distance_each_frame;
    player_acceleration( & board -> player, direction);
    board -> player.direction = direction;
    distance_each_frame = (1.0 / 60) * ((0.1 + (0.03 * board -> player.direction_reset)) * board -> player.speed);
    switch (direction) {
        case UP:
            board -> player.y = check_move_up(*board, board -> player.x, board -> player.y, distance_each_frame,0);
            break;

        case LEFT:
            board -> player.x = check_move_left(*board, board -> player.x, board -> player.y, distance_each_frame,0);
            break;
        case DOWN:
            board -> player.y = check_move_down(*board, board -> player.x, board -> player.y, distance_each_frame,0);
            break;

        case RIGHT:
            board -> player.x = check_move_right(*board, board -> player.x, board -> player.y, distance_each_frame,0);
            break;

        case NEUTRAL:
            break;
    }
    player_mana_gain(board);
    player_relic_steals(board);
    return 0;
}

int new_game() {
    Board board;
    Display_settings settings;
    char * name;
    int age;
    double frametime, extratime, time = 0, old_time;
    struct timespec end_time, new_time;
    struct timeval begin, end;
    /* Inits */
    board = init_board();
    MLV_create_window("Stealth", "Stealth", WIDTH * SCALE, HEIGHT * SCALE);
    MLV_init_audio();
    play_main_music();
    init_settings(&settings);
    /* Graphical menu */
    manage_menu(&settings);
    /* Main while */
    MLV_stop_music();
    while (1) {
        gettimeofday(&begin, 0);
        clock_gettime(CLOCK_REALTIME, &end_time);
        display_board(board, settings, time);

        /* si le gardien voit le player */
        if (guardians_move_and_detect(&board) == 1) {
            play_death_sound();
            display_death_screen(settings);
            break;
        }

        /* If the player win */
        if (is_game_over(board) == 1){
            play_winning_song();
            save_name_age_player(settings, &name, &age);
            savePlayerScore(name, age, (int) time, board.player.spend_mana);
            manage_ranking_screen(&settings);
            break;
        }
        keyboard_game_event(&board);
        clock_gettime(CLOCK_REALTIME, &new_time);
        frametime = (new_time.tv_sec - end_time.tv_sec);
        frametime += (new_time.tv_sec - end_time.tv_sec) / 1.0E9;
        extratime = 1.0 / 60 - frametime;
        if (extratime > 0) {
            MLV_wait_milliseconds((int)(extratime * 1000));
        }
        gettimeofday(&end, 0);
        old_time = time;
        time += (end.tv_sec - begin.tv_sec) + (end.tv_usec - begin.tv_usec) * 1e-6;
        update_panic(&board, time, old_time);
    }
    /* Closes */
    MLV_free_audio();
    MLV_free_window();
    return 0;
}

void panic_mode_end(Board * board) {
    int i;
    for (i = 0; i < board -> guardians_number; i++) {
        board -> guardians[i].vision = 4;
    }
    MLV_stop_music();
}

void panic_mode_start(Board * board) {
    int i;
    for (i = 0; i < board -> guardians_number; i++) {
        board -> guardians[i].vision = 6;
    }
    MLV_stop_music();
    play_alarm_music();
}

void player_mana_gain(Board * board) {
    if (board -> floor[(int)(board -> player.x)][(int)(board -> player.y)].type == MANA) {
        board -> floor[(int)(board -> player.x)][(int)(board -> player.y)].type = ROOM;
        board -> player.mana++;
        play_mana_sound();
    }
}

void player_relic_steals(Board * board) {
    int i;
    for (i = 0 ; i < board->relics_number ; i++) {
        if ((int)board -> player.x == board->relics[i].x && (int)(board -> player.y) == board->relics[i].y && board->relics[i].type == RELIC) {
            board -> floor[(int)(board -> player.x)][(int)(board -> player.y)].type = OLD_RELIC;
            board -> relics[i].type = OLD_RELIC;
            board->unstolen_relics_number--;
        }
    }
}

void update_panic(Board * board, double time, double old_time){
    if (board->panic >= 1 && (int) old_time < (int) time){
        board->panic--;
        if (board -> panic == 1) {
			panic_mode_end(board);
			board -> panic--;
		}
    }
}
