/*
File : cell.c
Name : Rajon Lionel
16/11/22
*/

#include "../include/cell.h"

Cell init_cell(CellType type, int x, int y) {
	Cell cell;
	cell.x = x;
	cell.y = y;
	cell.type = type;
	
	return cell;
}
