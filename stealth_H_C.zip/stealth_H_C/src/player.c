#include "../include/player.h"

Player init_player(int x, int y, int mana) {
    Player player;
    player.x = x;
    player.y = y;
    player.mana = mana;
    player.spend_mana = 0;
    player.direction_reset = 0;
    player.direction = DOWN;
    player.invisible = 0;
    player.speed = SPEED;
    player.max_speed = 0.9;
    return player;
}

void player_acceleration(Player * player, Direction new_direction) {
    double player_current_speed;
    player_current_speed = ((0.1 + (0.03 * player -> direction_reset)) * player -> speed);
    if (player -> direction == new_direction) {
        if (player_current_speed < SPEED + (player -> max_speed * SPEED)) {
            player -> direction_reset++;
        }
    } else {
        player -> direction_reset = 0;
    }
}
