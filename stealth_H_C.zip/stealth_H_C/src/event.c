#include "../include/event.h"

int keyboard_game_event(Board * board) {
    if (MLV_get_keyboard_state(MLV_KEYBOARD_SPACE) == MLV_PRESSED && board -> player.mana >= 2) {
        board -> player.invisible = 1;
        board -> player.mana -=1;
        board -> player.spend_mana += 1;
        mana_spawning(board);
    } else
        board -> player.invisible = 0;

    if ((MLV_get_keyboard_state(MLV_KEYBOARD_LSHIFT) == MLV_PRESSED || MLV_get_keyboard_state(MLV_KEYBOARD_RSHIFT) == MLV_PRESSED) && board -> player.mana >= 1){
        board -> player.max_speed = 1.2;
        board -> player.mana -= 2;
        board -> player.spend_mana += 2;
        mana_spawning(board);
        mana_spawning(board);
    }
    else
        board -> player.max_speed = 0.9;

    if (MLV_get_keyboard_state(MLV_KEYBOARD_z) == MLV_PRESSED)
        move(board, UP);

    else if (MLV_get_keyboard_state(MLV_KEYBOARD_q) == MLV_PRESSED)
        move(board, LEFT);
    else if (MLV_get_keyboard_state(MLV_KEYBOARD_s) == MLV_PRESSED)
        move(board, DOWN);
    else if (MLV_get_keyboard_state(MLV_KEYBOARD_d) == MLV_PRESSED)
        move(board, RIGHT);
    else
        move(board, NEUTRAL);
    
    return 0;
}

void manage_menu(Display_settings * settings){
    MLV_Event ev;
    MLV_Keyboard_button sym;
    int choice = 1, mouse_x, mouse_y;
    do{
        /* Display the setting screen */
        display_menu(*settings, choice);
        /* Wait an event (mouse or keyboard) */
        ev = MLV_wait_keyboard_or_mouse(&sym, NULL, NULL, &mouse_x, &mouse_y);
        switch(ev){
            case MLV_MOUSE_BUTTON:
                /* If the user clicks on the settings wheel */
                if (mouse_x >= settings->width - 50 && mouse_x <= settings->width - 10 && mouse_y >= 10 && mouse_y <= 50)
                    manage_settings(settings);
                break;
            case MLV_KEY:
                /* If a button is pressed */
                if (MLV_get_keyboard_state(sym) == MLV_PRESSED){
                    switch(sym){
                        case MLV_KEYBOARD_UP:
                            if (choice == 1)
                                choice = 2;
                            else
                                choice--;
                            break;
                        case MLV_KEYBOARD_DOWN:
                            if (choice == 2)
                                choice = 1;
                            else
                                choice++;
                            break;
                        case MLV_KEYBOARD_RETURN:
                            switch(choice){
                                case 1:
                                    return;
                                case 2:
                                    manage_ranking_screen(settings);
                                    break;
                            }
                            break;
                        default:
                            break;
                    }
                }
                break;
            default:
                printf("Impossible ! Error\n");
                exit(1);
        }

    }while(1);
}

void manage_ranking_screen(Display_settings * settings){
    Player_info * players_info;
    int nbr_players, mouse_x, mouse_y, sorting_mode = 0;
    /* Load players infos */
    if (NULL == (players_info = loadRanking(&nbr_players))){
        return ;
    }
    do{
        /* Display the array ranking */
        display_ranking_screen(players_info, *settings, nbr_players, sorting_mode);
        /* Wait a mouse click from user */
        MLV_wait_mouse(&mouse_x, &mouse_y);
        /* If user clicks on the top side of the array (grey part) */
        if (mouse_y >= settings->height/4 - settings->height/20 && mouse_y <= settings->height/4){
            /* If he clicks on time box */
            if (mouse_x >= settings->width/ 2 && mouse_x <= 2 * settings->width/3){
                /* Change sort mode */
                sorting_mode = switch_ranking_sorting_mode(sorting_mode, 1);
                /* Ascending ranking ordered by time score */
                if (sorting_mode == 1)
                    qsort(players_info, nbr_players, sizeof(Player_info), compare_time_player_descending);
                /* Descending */
                else
                    qsort(players_info, nbr_players, sizeof(Player_info), compare_time_player_ascending);
            }
            /* If he clicks on mana box */
            if (mouse_x >= 2 * settings->width/ 3 && mouse_x <= 5 * settings->width/6){
                /* Change sort mode */
                sorting_mode = switch_ranking_sorting_mode(sorting_mode, 2);
                /* Ascending ranking ordered by mana score */
                if (sorting_mode == 2)
                    qsort(players_info, nbr_players, sizeof(Player_info), compare_mana_player_descending);
                /* Descending */
                else
                    qsort(players_info, nbr_players, sizeof(Player_info), compare_mana_player_ascending);
            }
        }
        /* If he clicks on settings wheel */
        if (mouse_x >= settings->width - 50 && mouse_x <= settings->width - 10 && mouse_y >= 10 && mouse_y <= 50){
            manage_settings(settings);
        }
        /* If he clicks on the exit cross */
        if (mouse_x >= 10 && mouse_x <= 50 && mouse_y >= 10 && mouse_y <= 50){
            break;
        }               
    }while(1);
}

void manage_settings(Display_settings * settings){
    MLV_Event ev;
    MLV_Keyboard_button sym;
    int choice = 1, mouse_x, mouse_y;
    do{
        /* Display the setting screen */
        display_settings(*settings, choice);
        /* Wait an event (mouse or keyboard) */
        ev = MLV_wait_keyboard_or_mouse(&sym, NULL, NULL, &mouse_x, &mouse_y);
        switch(ev){
            case MLV_MOUSE_BUTTON:
                /* If the user clicks on a flag, it changes langage */
                if (mouse_y >= 0 && mouse_y <= 40){
                    if (mouse_x >= 0 && mouse_x <= 40)
                        settings->langage = 'f';
                    if (mouse_x >= 50 && mouse_x <= 90)
                        settings->langage = 'e';
                }
                /* If the user clicks on the exit cross */
                if (mouse_x >= settings->width - 50 && mouse_x <= settings->width - 10 && mouse_y >= 10 && mouse_y <= 50)
                    return;
                break;
            case MLV_KEY:
                /* If the button is pressed */
                if (MLV_get_keyboard_state(sym) == MLV_PRESSED){
                    switch(sym){
                        case MLV_KEYBOARD_UP:
                            if (choice == 1)
                                choice = 2;
                            else
                                choice--;
                            break;
                        case MLV_KEYBOARD_DOWN:
                            if (choice == 2)
                                choice = 1;
                            else
                                choice++;
                            break;
                        case MLV_KEYBOARD_RIGHT:
                            switch(choice){
                                case 1:
                                    settings->width+=10;
                                    MLV_change_window_size(settings->width, settings->height);
                                    break;
                                case 2:
                                    settings->height+=10;
                                    MLV_change_window_size(settings->width, settings->height);
                                    break; 
                            }
                            break;

                        case MLV_KEYBOARD_LEFT:
                            switch(choice){
                                case 1:
                                    settings->width-=10;
                                    MLV_change_window_size(settings->width, settings->height);
                                    break;
                                case 2:
                                    settings->height-=10;
                                    MLV_change_window_size(settings->width, settings->height);
                                    break; 
                            }
                            break;

                        default:
                            break;
                    }
                }
                break;
            default:
                printf("Impossible ! Error\n");
                exit(1);
        }

    }while(1);
}





