/*
File : main.c
Name : Rajon Lionel
16/11/22
*/

#include "../include/game.h"


int main(int argc, char * argv[]) {
	new_game();
    return 0;
}

