#include "../include/colli.h"

int check_colli(Board board, Guardian guardian) {
    double x, y;
    int panic;
    Direction direction = guardian.direction;
    x = guardian.x;
    y = guardian.y;
    panic = 0;
    if (board.panic > 0){
		panic = 1;
	}
    switch (direction) {
        case UP:
			if (y != check_move_up(board, x, y, 0.0,panic)) 
				return 1;
			break;	
        case LEFT:
			if (x != check_move_left(board, x, y, 0.0,panic)) 
				return 2;

            break;

        case DOWN:
			if (y != check_move_down(board, x, y, 0.0,panic)) 
				return 3;
            break;

        case RIGHT:
			if (x != check_move_right(board, x, y, 0.0,panic)) 
				return 4;			
            break;

        case NEUTRAL:
            break;
    }
    return 0;
}




double check_move_down(Board board, double x, double y, double distance_each_frame,int panic) {
    if (board.floor[(int)(x)][(int)(y +( panic * 1) + 0.6)].type == WALL) {
        y = (int)(y + ( panic * 1) + 0.6) - 0.6;
    } else if (board.floor[(int)(x - 0.5)][(int)(y + ( panic * 1) + 0.5)].type == WALL) {
        y = floor(y +( panic * 1) + 0.5) - sqrt( (1.0/4.0) - pow(x - (int)x, 2));
    } else if (board.floor[(int)(x + 0.5)][(int)(y +( panic * 1) + 0.5)].type == WALL) {
        y = (int)(y +( panic * 1) + 0.5) - sqrt( (1.0/4.0) - pow((int)x + 1 - x, 2)); 
    } else {
        y += distance_each_frame;
    }
    return y;
}

double check_move_left(Board board, double x, double y, double distance_each_frame, int panic) {
    if (board.floor[(int)(x - ( panic * 1) - 0.6)][(int)(y)].type == WALL) {
        x = (int)(x - ( panic * 1)) + 0.5;
    } else if (board.floor[(int)(x - ( panic * 1) - 0.5)][(int)(y + 0.5)].type == WALL) {
        x = (int)(x - ( panic * 1) - 0.5) + 1 + sqrt( (1.0/4.0) - pow((int)y + 1 - y, 2));
    } else if (board.floor[(int)(x -( panic * 1) - 0.5)][(int)(y - 0.5)].type == WALL) {
        x = (int)(x -( panic * 1) - 0.5) + 1 + sqrt( (1.0/4.0) - pow(y - (int)y, 2)); 
    } else {
        x -= distance_each_frame;
    }
    return x;
}

double check_move_right(Board board, double x, double y, double distance_each_frame, int panic) {
    if (board.floor[(int)(x +( panic * 1)+ 0.6)][(int)(y)].type == WALL) {
        x = (int)(x +( panic * 1)+ 0.6) - 0.6;

    } else if (board.floor[(int)(x + 0.5)][(int)(y - 0.5)].type == WALL) {
        x = (int)(x + ( panic * 1) + 0.5) - sqrt( (1.0/4.0) - pow(y - (int)y, 2)); 

    } else if (board.floor[(int)(x + 0.5)][(int)(y + 0.5)].type == WALL) {
        x = (int)(x + ( panic * 1) + 0.5) - sqrt( (1.0/4.0) - pow((int)y + 1 - y, 2)); 

    } else {
        x += distance_each_frame;
    }
    return x;
}

double check_move_up(Board board, double x, double y, double distance_each_frame, int panic) {
    if (board.floor[(int)(x)][(int)(y -( panic * 1)- 0.6)].type == WALL) {
        y = (int) (y -( panic * 1)) + 0.5;
    } else if (board.floor[(int)(x - 0.5)][(int)(y - 0.5)].type == WALL) {
        y = (int)(y -( panic * 1) - 0.5) + 1 + sqrt((1.0/4.0) - pow(x - (int)x, 2));

    } else if (board.floor[(int)(x + 0.5)][(int)(y - 0.5)].type == WALL) {
        y = (int)(y -( panic * 1) - 0.5) + 1 + sqrt((1.0/4.0) - pow((int)x + 1 - x, 2)); 

    } else {
        y -= distance_each_frame;
    }
    return y;
}



int does_guardian_see_point(Board board , Guardian guardian, double point_x, double point_y) {
    int p, a, b, ya, xb;
    double x0, y0, x1, y1, pa, pb;
    /* Si le point est trop éloigné du gardien (hors de son champ de vision maximal), pas besoin de vérifier */
    if (euclidean_distance((int) point_x, (int) point_y, (int) (guardian.x), (int) (guardian.y)) > guardian.vision)
        return 0;

    /* On vérifie que la valeur p = 0 donne bien le point P0, et p = 1 donne bien P1. */
    p = 0;
    if (!(p * ((int) guardian.x) + (1 - p) * ((int) point_x) == ((int) point_x) && p * ((int) guardian.y) + (1 - p) * ((int) point_y) == ((int) point_y))){
        printf("Première condition de does_guardian_see_point non vérifiée. Sortie du programme.\n");
        printf("Calcul : (%d,%d) Attendu : (%d,%d)\n", p * ((int) guardian.x) + (1 - p) * ((int) point_x), p * ((int) guardian.y) + (1 - p) * ((int) point_y), (int) point_x, (int) point_y);
        exit(1);
    }

    p = 1;
    if (!(p * ((int) guardian.x) + (1 - p) * ((int) point_x) == ((int) guardian.x) && p * ((int) guardian.y) + (1 - p) * ((int) point_y) == ((int) guardian.y))){
        printf("Première condition de does_guardian_see_point non vérifiée. Sortie du programme.\n");
        printf("Calcul : (%d,%d) Attendu : (%d,%d)\n", p * ((int) guardian.x) + (1 - p) * ((int) point_x), p * ((int) guardian.y) + (1 - p) * ((int) point_y), (int) point_x, (int) point_y);
        exit(1);
    }

    /** 
    Pour trouver les cases traversées, on commence par trouver les côtés des cases qui sont traversées. 
    Comme ce sont des segments sur une droite de la forme x = a ou y = b, il suffit de calculer les intersections entre ces droites et le segment [P0, P1].
    **/

    /* On commence par chercher les intersections pour les droite x = a */

    /* On détermine quel point sera P0 et quel point sera P1. */
    if (point_x <= guardian.x){
        x0 = point_x;
        y0 = point_y;
        x1 = guardian.x;
        y1 = guardian.y;
    }else{
        x0 = guardian.x;
        y0 = guardian.y;
        x1 = point_x;
        y1 = point_y;
    }

    for (a = (int) x0; a <= x1; a++){
        pa = (a - x0) / ((x1) - x0);
        if (pa >= 0 && pa <= 1){
            ya = (int) (y0 + ((y1) - y0) / ((x1) - x0) * (a - x0));
            /* Si un mur est détecté */
            if (board.floor[a][ya].type == WALL)
                return 0;
        }
    }

    /* On fait la même pour les droites y = b */

    /* On détermine quel point sera P0 et quel point sera P1. */
    if (point_y <= guardian.y){
        x0 = point_x;
        y0 = point_y;
        x1 = guardian.x;
        y1 = guardian.y;
    }else{
        x0 = guardian.x;
        y0 = guardian.y;
        x1 = point_x;
        y1 = point_y;
    }

    for (b = (int) y0; b <= y1; b++){
        pb = (b - y0) / ((y1) - y0);
        if (pb >= 0 && pb <= 1){
            xb = (int) (x0 + ((x1) - x0) / ((y1) - y0) * (b - y0));
            /* Si un mur est détecté */
            if (board.floor[xb][b].type == WALL)
                return 0;
            
        }
    }
    /* Si aucun mur n'a été trouvé parmis les intersections, le point est visible. */
    return 1;
}

int guardian_detect_player(Board board, Guardian guardian) {
    /* Si le joueur est invisible, pas la peine de vérifier */
    if (board.player.invisible == 1)
        return 0;
    return does_guardian_see_point(board, guardian, board.player.x, board.player.y);
}

int guardian_detect_relic(Board board, Guardian guardian, int * index_relic) {
    int i;
    for (i = 0 ; i < board.relics_number ; i++) {
        if (board.relics[i].type == OLD_RELIC && does_guardian_see_point(board, guardian, board.relics[i].x, board.relics[i].y)){
            *index_relic = i;
            return 1;
        }
    }
    return 0;
}

int round(double value) {
    return (int)(value + 0.5);
}
