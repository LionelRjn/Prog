#ifndef __Player__
#define __Player__

#include "cell.h"

#define SPEED 10.0

typedef enum {
    UP,
    DOWN,
    LEFT,
    RIGHT,
    NEUTRAL
} Direction;

typedef struct Player{
    double x;
    double y;
    int mana;
    int spend_mana;
    int direction_reset;
    int invisible;
    double speed;
    double max_speed;
    Direction direction;
} Player;

/* Init the player */
Player init_player(int x, int y, int mana);
/* Manage the player's acceleration */
void player_acceleration(Player * player, Direction new_direction);

#endif
