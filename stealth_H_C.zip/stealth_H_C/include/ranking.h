#ifndef __Ranking__
#define __Ranking__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char name[50];
	int age;
	int time_score;
	int mana_score;
} Player_info;

int compare_mana_player_ascending(const void *a, const void *b);

int compare_mana_player_descending(const void *a, const void *b);

int compare_time_player_ascending(const void *a, const void *b);

int compare_time_player_descending(const void *a, const void *b);

Player_info * loadRanking(int * nbr_players);

int savePlayerScore(const char * name, int age, int time_score, int mana_score);

int saveRanking(Player_info * players_info, int nbr_players);

int switch_ranking_sorting_mode(int sorting_mode, int new_choice);

#endif