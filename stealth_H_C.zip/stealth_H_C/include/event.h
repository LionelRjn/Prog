#ifndef __Event__
#define __Event__

#include "display.h"
#include "game.h"

/* Manage all keyboard event during the game */
int keyboard_game_event(Board * board);

/* Manage events on graphical menu */
void manage_menu(Display_settings * settings);

/* Manage events on graphical ranking screen */
void manage_ranking_screen(Display_settings * settings);

/* Manage events on graphical settings */
void manage_settings(Display_settings * settings);

#endif
