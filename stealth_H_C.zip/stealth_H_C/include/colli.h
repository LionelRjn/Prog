#ifndef __Colli__
#define __Colli__

#include <stdio.h>
#include <math.h>
#include "board.h"

/* Check if guardian is in front of a wall */
int check_colli(Board board, Guardian guardian);


/* Check if the point can move down */
double check_move_down(Board board, double x, double y, double distance_each_frame, int panic);

/* Check if the point can move left */
double check_move_left(Board board, double x, double y, double distance_each_frame, int panic);

/* Check if the point can move right */
double check_move_right(Board board, double x, double y, double distance_each_frame, int panic);

/* Check if the point can move up */
double check_move_up(Board board, double x, double y, double distance_each_frame, int panic);

/* Check if guardian can see the point. This function is used in guardian_detect_player and guardian_detect_relic. */
int does_guardian_see_point(Board board , Guardian guardian, double point_x, double point_y);

/* Check if guardian detects the player */
int guardian_detect_player(Board board, Guardian guardian);

/* Check if guardian detects a relic */
int guardian_detect_relic(Board board, Guardian guardian, int * index_relic);

/* Return the rounded value */
int round(double value);

#endif
