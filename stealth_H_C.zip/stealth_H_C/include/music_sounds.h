#ifndef __MusicSounds__
#define __MusicSounds__

#include <MLV/MLV_all.h>

void play_main_music();

void play_death_sound();

void play_mana_sound();

void play_winning_song();

void play_alarm_music();

#endif