#ifndef __Game__
#define __Game__

#define _POSIX_C_SOURCE 199309L

#include "colli.h"
#include "event.h"
#include "display.h"
#include "music_sounds.h"
#include <MLV/MLV_all.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

/* Try to move all guardians forward */
int all_guard_forward(Board * board);

/* Manage guardian direction and position if there is a wall by calling checkColli */
int change_direction(Board board, Guardian * guardian);

/* Calculates the euclidean distance between 2 points */
int euclidean_distance(int x1, int y1, int x2, int y2);

/* Check and exit the game if the game is over */
int is_game_over(Board board);

/* Manage the move and the detection of Guardians, calling "guardForward","checkWall","newGuardSpeed","guardianDetection" */
int guardians_move_and_detect(Board * board);

/* Auto-regenerate mana */
void mana_spawning(Board * board);

/* Move the player */
int move(Board * board, Direction direction);

/* Create a new Game*/
int new_game();

/* Close the panic mode */
void panic_mode_end(Board * board);

/* Initialize the panic mode */
void panic_mode_start(Board * board);

/* Check and permits player to eat mana */
void player_mana_gain(Board * board);

/* Check and permits player to earn/steal a relic */
void player_relic_steals(Board * board);

/* Updates panic */
void update_panic(Board * board, double time, double old_time);

#endif

