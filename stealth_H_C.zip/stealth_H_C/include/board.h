/*
File : board.h
Name : Rajon Lionel
16/11/22
*/



#ifndef __Board__
#define __Board__

#include "guardian.h"
#include <time.h>
#include <math.h>

#define WIDTH 60
#define HEIGHT 45

typedef struct {
	Cell floor[WIDTH][HEIGHT];
	Player player;
	Guardian * guardians;
	int guardians_number;
	Cell * relics;
	int relics_number;
	int unstolen_relics_number;
	int panic;
} Board;

/* Recursive function to initalize random walls on the board */
void algo_generate_random_walls(Board * board, int minside, int x, int y, int x_start, int y_start);

/* Generate and check random coords for guardians */
void check_generate_random_coord_guardian_relics(Board board, int * rand_x, int * rand_y);

/* Calculates euclidian distance between two points */
int euclidean_distance(int x1, int y1, int x2, int y2);

/* Initializes the Level and returns it. */
Board init_board();

/* Initializes an array of guardians, depending on the game mode */
Guardian * init_guardians(Board board);

/* Initializes relics */
Cell * init_relics_list(Board * board);

/* Initializes walls of the board */
void init_walls(Board * board, int minside);

/* Remove a relic from the relic list */
void remove_relic(Board * board, int index);

#endif
