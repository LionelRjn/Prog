#ifndef __Guardian__
#define __Guardian__

#include "player.h"
#include <time.h>
#include <assert.h>
#include <math.h>

typedef struct {
	double x;
	double y;
	int vision;
	double speed;
	Direction direction;
} Guardian;

/* Initializes guardian */
Guardian init_guardian(int x, int y, int vision);

/* Try to move the guardian forward */
int guard_forward(Guardian * guardian,int panic);

/* Change the guardian moovement speed between 0.3 and 0.8 of SPEED */
void new_guard_speed(Guardian * guardian);

void guardian_random_direction(Guardian * guardian);

#endif
