/*
File : cell.h
Name : Rajon Lionel
16/11/22
*/



#ifndef __Cell__
#define __Cell__

#include <stdio.h>
#include <stdlib.h>

typedef enum {
	WALL,
	WALL_OPENING,
	ROOM,
	MANA,
	RELIC,
	OLD_RELIC
} CellType;

typedef struct {
	int x;
	int y;
	CellType type;
} Cell;

/* Initializes a cell with the type of the cell and returns it. */
Cell init_cell(CellType type, int x, int y);

#endif

