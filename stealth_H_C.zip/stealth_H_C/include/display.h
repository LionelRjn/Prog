#ifndef __Display__
#define __Display__

#include <MLV/MLV_all.h>

#include "board.h"
#include "ranking.h"

#define SCALE 20

typedef struct{
    char langage; /* f : french e : english */
    int width;
    int height;
    int scale;
    MLV_Color player_color;
    MLV_Color guardian_color;
    MLV_Color wall_color;
    MLV_Color relic_color;
    MLV_Color background_color;
} Display_settings;

/* Give the border's color of the n-th option, depending on choice. This auxiliary function is used in display_menu() and display_settings() function. */
MLV_Color color_depending_choice_and_number(int choice, int n, MLV_Color background_color);

/* Display the board */
void display_board(Board board, Display_settings settings, double time);

/* Display the cell according to the cell type of the argument. This auxiliary function is used in the display_board() function. */
void display_cell_board(Display_settings settings, Cell cell, int panic);

/* Display the death screen, when the game is over and player losed */
void display_death_screen(Display_settings settings);

/* Display all guardians. This auxiliary function is used in the display_board() function. */
void display_guardians(Board board, Display_settings settings);

/* Display infos */
void display_info_in_game(Board board, Display_settings settings, double time);

/* Display the player. This auxiliary function is used in the display_board() function. */
void display_player(Board board, Display_settings settings);

/* Display the menu screen */
void display_menu(Display_settings settings, int choice);

/* Display the option in settings. This auxiliary function is used in the display_settings() function. */
void display_option_settings(Display_settings settings, char * fr_str, char * en_str, int int_to_print, int choice, int number_option, int y);

/* Display the ranking screen */
void display_ranking_screen(Player_info * players_info, Display_settings settings, int nbr_players, int sorting_mode);

/* Display the settings screen */
void display_settings(Display_settings settings, int choice);

/* Intialize the display settings */
void init_settings(Display_settings * settings);

/* Save graphically the name and the age of the player with input boxes */
void save_name_age_player(Display_settings settings, char ** name, int * age);

/* Set, resize and draw image, for unique usage */
void set_and_draw_image(const char * path, int x, int y, int width, int height);

/* Set and resize image */
MLV_Image * set_image(const char * name, int width, int height);

#endif
