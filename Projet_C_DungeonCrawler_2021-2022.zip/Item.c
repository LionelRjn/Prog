/* Dos Santos Loïc */
/* Création : 30-10-2021 */
/* Dernière modification : 30-10-2021 */
#include "Item.h"

Item init_item(int quality) {
	Item item;
	int random_number;

	random_number = rand() % 3;
	switch(random_number) {
		case 0: item.type = ARMOR; break;
		case 1: item.type = WEAPON; break;
		case 2: item.type = WAND; break;
	}
	item.quality = quality;

	return item;
}

void print_item(Item item) {
	switch(item.type) {
		case ARMOR: printf("Armor, Quality:%d\n", item.quality); break;
		case WEAPON: printf("Weapon, Quality:%d\n", item.quality); break;
		case WAND: printf("Wand, Quality:%d\n", item.quality); break;
	}
}