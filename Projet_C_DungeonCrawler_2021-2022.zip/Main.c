/* Dos Santos Loïc */
/* Création : 17-10-2021 */
/* Dernière modification : 17-10-2021 */
#include <stdio.h>
#include <stdlib.h>
#include "Level.h"
#include "Action.h"
#include "Affichage.h"

int main(int argc, char const *argv[]) {
	Level level;
	/*char move_key;*/

	srand(time(NULL));

	/*
	init_first_floor(&level);
	print_floor_ascii(level);

	while(1) {
		player_action_ascii(&level);
		print_floor_ascii(level);
	}
	*/

	init_first_floor(&level);
	MLV_create_window("Rectangle", "Rectangle", WIDTH*20,HEIGHT*20);
	affichage(level);
	MLV_wait_seconds(10);
    MLV_free_window();
	
	return 0;
}
