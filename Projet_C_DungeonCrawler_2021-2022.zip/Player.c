/* Dos Santos Loïc */
/* Création : 17-10-2021 */
/* Dernière modification : 17-10-2021 */
#include "Player.h"

Player init_player(int height, int width) {
	Player player;

	player.Atk = BASE_STAT;
	player.Int = BASE_STAT;
	player.Def = BASE_STAT;
	player.Hp = getMaxHp(player.Def);
	player.Mp = getMaxMp(player.Int);
	player.Exp = 0;
	player.Lv = 1;
	/* A changer */
	player.x = width / 2;
	player.y = height / 2;
	player.direction = SOUTH;

	return player;
}

void print_player(Player player) {
	printf("Player: %d/%d HP|%d/%d MP, Atk:%d Int:%d Def:%d\n", player.Hp,
		getMaxHp(player.Def), player.Mp, getMaxMp(player.Int),
		player.Atk, player.Int, player.Def);
}

void add_exp(Player *player, int exp_value) {
	player->Exp += exp_value;

	if(player->Exp >= expRequireNextLv(player->Lv)) {
		printf("Console: Player leveled up.\n");
		player->Exp -= expRequireNextLv(player->Lv);
		player->Lv++;
		player->Hp = getMaxHp(player->Def);
		player->Mp = getMaxMp(player->Int);
	}
}

void add_atk_points(Player *player, int points) {
	player->Atk += points;
}

void add_int_points(Player *player, int points) {
	player->Int += points;
	player->Mp = getMaxMp(player->Int);
}

void add_def_points(Player *player, int points) {
	player->Def += points;
	player->Hp = getMaxHp(player->Def);
}

int move(Player *player, Direction direction, int height, int width) {
	player->direction = direction;
	if((player->x == 1 && direction == WEST) || (player->x == width - 2 && direction == EAST))
		return 0;
	if((player->y == 1 && direction == NORTH) || (player->y == height - 2 && direction == SOUTH))
		return 0;
	switch(direction) {
		case NORTH: player->y--; break;
		case SOUTH: player->y++; break;
		case EAST: player->x++; break;
		case WEST: player->x--; break;
	}
	return 1;
}

int player_melee_attack_damage(Player player) {
	float random_number;
	int damage;

	random_number = rand() % 41 + 80;
	random_number /= 100;

	damage = random_number * player.Atk;

	return damage;
}

/* /!\ Attention si plus de Mana. */
int player_magic_attack_damage(Player *player) {
	float random_number;
	int damage;

	random_number = rand() % 41 + 80;
	random_number /= 100;

	damage = random_number * (2 * player->Int);
	player->Mp -= 20;

	return damage;
}

int player_is_dead(Player player) {
	if(player.Hp > 0)
		return 0;
	return 1;
}