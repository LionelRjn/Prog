/* Dos Santos Loïc */
/* Création : 17-10-2021 */
/* Dernière modification : 17-10-2021 */
#include "Monster.h"

Monster init_monster() {
	Monster monster;

	monster.Hp = MONSTER_HP;
	monster.Atk = MONSTER_ATK;

	return monster;
}

void print_monster(Monster monster) {
	printf("Monster:%d/%d HP, Atk:%d\n", monster.Hp, MONSTER_HP, monster.Atk);
}

int monster_melee_attack_damage(Monster monster) {
	float random_number;
	int damage;

	random_number = rand() % 41 + 80;
	random_number /= 100;

	damage = random_number * monster.Atk;

	return damage;
}

int monster_is_dead(Monster monster) {
	if(monster.Hp > 0)
		return 0;
	return 1;
}