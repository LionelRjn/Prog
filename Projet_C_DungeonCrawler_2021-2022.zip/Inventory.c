/* Dos Santos Loïc */
/* Création : 15-11-2021 */
/* Dernière modification : 15-11-2021 */
#include "Inventory.h"

Inventory init_inventory() {
	Inventory inventory;

	inventory.slots_occupied = 0;

	return inventory;
}

void print_inventory(Inventory inventory) {
	int i;

	if(!inventory.slots_occupied)
		printf("Inventory is empty.\n");
	for(i = 0; i < inventory.slots_occupied; i++) {
		print_treasure(inventory.slots[i]);
	}
}

int inventory_is_full(Inventory inventory) {
	if(inventory.slots_occupied == MAX_SLOTS)
		return 1;
	return 0;
}

int equiped_armor(Inventory inventory) {
	int i, quality;

	quality = 0;
	for(i = 0; i < inventory.slots_occupied; i++) {
		if(inventory.slots[i].type == ITEM) {
			if(inventory.slots[i].item.type == ARMOR) {
				if(inventory.slots[i].item.quality > quality)
					quality = inventory.slots[i].item.quality;	
			}
		}
	}

	return quality;
}

int equiped_weapon(Inventory inventory) {
	int i, quality;

	quality = 0;
	for(i = 0; i < inventory.slots_occupied; i++) {
		if(inventory.slots[i].type == ITEM) {
			if(inventory.slots[i].item.type == WEAPON) {
				if(inventory.slots[i].item.quality > quality)
					quality = inventory.slots[i].item.quality;	
			}
		}
	}

	return quality;
}

int equiped_wand(Inventory inventory) {
	int i, quality;

	quality = 0;
	for(i = 0; i < inventory.slots_occupied; i++) {
		if(inventory.slots[i].type == ITEM) {
			if(inventory.slots[i].item.type == WAND) {
				if(inventory.slots[i].item.quality > quality)
					quality = inventory.slots[i].item.quality;	
			}
		}
	}

	return quality;
}

void add_treasure(Inventory *inventory, Treasure treasure) {
	inventory->slots[inventory->slots_occupied] = treasure;
	inventory->slots_occupied++;
}

Treasure remove_treasure(Inventory *inventory, int slot_number) {
	Treasure treasure_removed;
	int i;

	treasure_removed = inventory->slots[slot_number];
	for(i = slot_number; i < inventory->slots_occupied; i++) {
		inventory->slots[i] = inventory->slots[i + 1];
	}
	inventory->slots_occupied--;

	return treasure_removed;
}