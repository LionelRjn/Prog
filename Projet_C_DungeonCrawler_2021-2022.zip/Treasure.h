/* Dos Santos Loïc */
/* Création : 30-10-2021 */
/* Dernière modification : 30-10-2021 */
#ifndef __TREASURE__H__
#define __TREASURE__H__
#include <stdio.h>
#include <stdlib.h>
#include "Potion.h"
#include "Item.h"

typedef enum {
	POTION,
	ITEM
} TreasureType;

typedef struct {
	TreasureType type;
	union {
		Potion potion;
		Item item;
	};
} Treasure;

/* Initializes a Treasure with its type and returns the Treasure. */
Treasure init_treasure(TreasureType type, int stage);

/* Print all useful informations about the Treasure. */
void print_treasure(Treasure treasure);

/* Print the lore about the Treasure. */
/*void print_treasure_description(Treasure t);*/

#endif