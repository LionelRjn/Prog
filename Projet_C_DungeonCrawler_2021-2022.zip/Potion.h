/* Dos Santos Loïc */
/* Création : 30-10-2021 */
/* Dernière modification : 30-10-2021 */
#ifndef __POTION__H__
#define __POTION__H__
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef enum {
	HEALING_POTION,
	MANA_POTION,
	REGEN_POTION,
	ACCURACY_POTION,
	WISDOM_POTION
} PotionType;

typedef struct {
	PotionType type;
} Potion;

/* Initializes a Potion with a random type and returns it. */
Potion init_potion();

/* Print all useful informations about the Potion. */
void print_potion(Potion potion);

#endif