/* Dos Santos Loïc */
/* Création : 20-10-2021 */
/* Dernière modification : 20-10-2021 */
#ifndef __AFFICHAGE__H_
#define __AFFICHAGE__H__
#include <stdio.h>
#include <MLV/MLV_all.h>
#include <stdlib.h>
#include "Level.h"


/* Print the cell in the terminal with mlv */
void print_cell_mlv(Cell cell, int i, int y);

void affichage(Level level);
	

#endif

