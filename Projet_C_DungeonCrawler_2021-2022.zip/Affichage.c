/* Dos Santos Loïc */
/* Création : 17-10-2021 */
/* Dernière modification : 17-10-2021 */
#include "Affichage.h"

void print_cell_mlv(Cell cell, int i, int y) {
	int taille_cote_carre=20;
	switch(cell.type) {
		/*
		 * Mur gris ; room noir ; monstre rouge ; trésor jaune ; escalier vert ; perso bleu
		 * */
		case WALL: MLV_draw_filled_rectangle((i*20),(y*20) ,taille_cote_carre ,taille_cote_carre ,MLV_rgba(96,96,96,150)); break;
		case ROOM: MLV_draw_filled_rectangle((i*20),(y*20) ,taille_cote_carre ,taille_cote_carre ,MLV_rgba(0,0,0,150)); break;
		case MONSTER: MLV_draw_filled_rectangle((i*20),(y*20) ,taille_cote_carre ,taille_cote_carre ,MLV_rgba(255,0,0,150)); break;
		case TREASURE: MLV_draw_filled_rectangle((i*20),(y*20),taille_cote_carre ,taille_cote_carre ,MLV_rgba(255,255,0,150)); break;
		case STAIR_UP: MLV_draw_filled_rectangle((i*20),(y*20) ,taille_cote_carre ,taille_cote_carre ,MLV_rgba(0,255,0,150)); break;
		case STAIR_DOWN: MLV_draw_filled_rectangle((i*20),(y*20) ,taille_cote_carre ,taille_cote_carre ,MLV_rgba(20,148,20,150)); break;
	}
}

void affichage(Level level){
	int i, j;
	int rayon;
	rayon = 10;
	for(i = 0; i < HEIGHT; i++) {
		for(j = 0; j < WIDTH; j++) {
			if(level.player.x == j && level.player.y == i)
				MLV_draw_filled_circle( (i*20), (j*20) , rayon, MLV_rgba(0,0,255,255));	
			else
				print_cell_mlv(level.floor[i][j],j,i);
		}
	}
	MLV_actualise_window();
}
