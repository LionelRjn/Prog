/* Dos Santos Loïc */
/* Création : 20-10-2021 */
/* Dernière modification : 20-10-2021 */
#ifndef __LEVEL__H__
#define __LEVEL__H__
#include <stdio.h>
#include <stdlib.h>
#include "Cell.h"
#include "Inventory.h"

#define HEIGHT 43
#define WIDTH 63

/* floor[y][x] */

typedef struct {
	Cell floor[HEIGHT][WIDTH];
	int stage;
	Player player;
	Inventory inventory;
} Level;

/* Initializes the floor with room everywhere and walls on the borders. */
void init_empty_floor(Level *level);

/* Initializes the first floor. */
void init_first_floor(Level *level);

/* Print the floor from the level in the terminal. */
void print_floor_ascii(Level level);

#endif