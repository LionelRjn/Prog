/* Dos Santos Loïc */
/* Création : 30-10-2021 */
/* Dernière modification : 30-10-2021 */
#include "Treasure.h"

Treasure init_treasure(TreasureType type, int stage) {
	Treasure treasure;

	treasure.type = type;
	if(type == POTION)
		treasure.potion = init_potion();
	else if(type == ITEM)
		treasure.item = init_item(stage);

	return treasure;
}

void print_treasure(Treasure treasure) {
	if(treasure.type == POTION)
		print_potion(treasure.potion);
	if(treasure.type == ITEM)
		print_item(treasure.item);
}