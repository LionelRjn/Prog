/* Dos Santos Loïc */
/* Création : 11-10-2021 */
/* Dernière modification : 11-10-2021 */
#ifndef __PLAYER__H__
#define __PLAYER__H__
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define BASE_STAT 10
#define getMaxHp(Def) 10 * Def
#define getMaxMp(Int) 10 * Int - 50
#define expRequireNextLv(Lv) 350 + 50 * Lv

typedef enum {
	NORTH,
	EAST,
	SOUTH,
	WEST
} Direction;

/* x = width(j), y = height(i) */
typedef struct {
	int Hp;
	int Mp;
	unsigned int Atk;
	unsigned int Int;
	unsigned int Def;
	unsigned int Exp;
	unsigned int Lv;
	int x;
	int y;
	Direction direction;
} Player;

/* Initializes a Player with Atk, Int, Def and with centered coordonates
 * and returns the player. */
Player init_player(int height, int width);

/* Print all useful informations about the Player. */
void print_player(Player player);

/* Print the lore about the Player. */
/*void print_player_description(Player player);*/

/* Add the exp_value to the Player's Exp.
 * If the new Exp go through the Level up threshold Player's Lv increase by one
 * and the Exp is consumed. */
void add_exp(Player *player, int exp_value);

/* Add a number of points in Atk of the Player. */
void add_atk_points(Player *player, int points);

/* Add a number of points in Int of the Player. */
void add_int_points(Player *player, int points);

/* Add a number of points in Def of the Player. */
void add_def_points(Player *player, int points);

/* /!\ A changer */
/* Change the coordonates and its direction.
 * Returns 1 if the player succeeded to move,
 * Returns 0 if he was blocked by a border wall. */
int move(Player *player, Direction direction, int height, int width);

/* Calculate the melee attack damage of the Player and returns the damage value. */
int player_melee_attack_damage(Player player);

/* /!\ We need to check if we have enough Mp before. */
/* Calculate the magic attack damage of the Player and returns the damage value. */
int player_magic_attack_damage(Player *player);

/* Return 1 if the Player's Hp are equals or lower than 0,
 * Return 0 otherwise. */
int player_is_dead(Player player);

#endif