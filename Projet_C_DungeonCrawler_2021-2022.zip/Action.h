/* Dos Santos Loïc */
/* Création : 31-10-2021 */
/* Dernière modification : 31-10-2021 */
#ifndef __ACTION__H__
#define __ACTION__H__
#include <stdio.h>
#include <stdlib.h>
#include "Level.h"
#include "Player.h"
#include "Monster.h"

#define CRIT_CHANCE 0.05

/* Returns the Exp gained depending on the level's stage. */
int gained_exp(Level level);

/* Returns the number of monsters in range of the Player. */
int monsters_in_range(Level level);

/* Returns a Monster array. The array needs to be freed later. */
Monster* get_monsters_in_range(Level level, int number_of_monsters);

/* Check if a monster is in range to attack the Player if it is attacks him.
 * Return 1 if an attack has been performed,
 * Return 0 otherwise. */
int monster_attack_turn(Level *level);

/* Player does a melee attack on a Monster at x,y position.
 * Returns 1 if Monster has been hit,
 * Returns 0 otherwise. */
int player_melee_attack_monster(Level *level, int x, int y);

/* Player does a magic attack on a Monster at x,y position.
 * Returns 1 if Monster has been hit,
 * Returns 0 otherwise. */
int player_magic_attack_monster(Level *level, int x, int y);

/* Handle the action possible by the Player. */
void player_action_ascii(Level *level);

#endif