/* Dos Santos Loïc */
/* Création : 17-10-2021 */
/* Dernière modification : 17-10-2021 */
#include "Cell.h"

Cell init_cell(CellType type, int stage) {
	Cell cell;
	cell.type = type;
	int random_number;

	switch(type) {
		case WALL: break;
		case ROOM: break;
		case MONSTER: cell.monster = init_monster(MONSTER_HP); break;
		case TREASURE: random_number = rand() % 2; cell.treasure = init_treasure(random_number, stage); break;
		case STAIR_UP: break;
		case STAIR_DOWN: break;
	}
	
	return cell;
}

void print_cell(Cell cell) {
	switch(cell.type) {
		case WALL: printf("Wall\n"); break;
		case ROOM: printf("Room\n"); break;
		case MONSTER: print_monster(cell.monster); break;
		case TREASURE: print_treasure(cell.treasure); break;
		case STAIR_UP: printf("Stair Up\n"); break;
		case STAIR_DOWN: printf("Stair Down\n"); break;
	}
}

void print_cell_ascii(Cell cell) {
	switch(cell.type) {
		case WALL: printf("#"); break;
		case ROOM: printf(" "); break;
		case MONSTER: printf("M"); break;
		case TREASURE: printf("T"); break;
		case STAIR_UP: printf("^"); break;
		case STAIR_DOWN: printf("v"); break;
	}
}