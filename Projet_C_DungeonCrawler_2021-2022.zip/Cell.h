/* Dos Santos Loïc */
/* Création : 12-10-2021 */
/* Dernière modification : 17-10-2021 */
#ifndef __CELL__H__
#define __CELL__H__
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Player.h"
#include "Monster.h"
#include "Treasure.h"

typedef enum {
	WALL,
	ROOM,
	MONSTER,
	TREASURE,
	STAIR_UP,
	STAIR_DOWN
} CellType;

typedef struct {
	CellType type;
	union {
		Monster monster;
		Treasure treasure;
	};
} Cell;

/* Initializes a cell with the type of the cell and returns it. */
Cell init_cell(CellType type, int stage);

/* Print all informations about the element in the cell. */
void print_cell(Cell cell);

/* Print the cell in the terminal. */
void print_cell_ascii(Cell cell);

#endif