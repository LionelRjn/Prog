/* Dos Santos Loïc */
/* Création : 31-10-2021 */
/* Dernière modification : 31-10-2021 */
#include <unistd.h>
#include "Action.h"

int gained_exp(Level level) {
	return 80 + 5 * level.stage;
}

int monsters_in_range(Level level) {
	int number_of_monsters, i, j;

	number_of_monsters = 0;
	for(i = level.player.y - 1; i < level.player.y + 2; i++) {
		for(j = level.player.x - 1; j < level.player.x + 2; j++) {
			if(level.floor[i][j].type == MONSTER)
				number_of_monsters++;
		}
	}
	return number_of_monsters;
}

Monster* get_monsters_in_range(Level level, int number_of_monsters) {
	Monster* monster_array;
	int i, j, index;

	monster_array = (Monster*)malloc(sizeof(Monster) * number_of_monsters);
	index = 0;

	for(i = level.player.y - 1; i < level.player.y + 2; i++) {
		for(j = level.player.x - 1; j < level.player.x + 2; j++) {
			if(level.floor[i][j].type == MONSTER) {
				monster_array[index] = level.floor[i][j].monster;
				index++;
			}
		}
	}

	return monster_array;
}

int monster_attack_turn(Level *level) {
	int number_of_monsters, index, damage, random_crit;
	Monster* monster_array;

	number_of_monsters = monsters_in_range(*level);

	if(!number_of_monsters)
		return 0;
	monster_array = get_monsters_in_range(*level, number_of_monsters);
	for(index = 0; index < number_of_monsters; index++) {
		damage = monster_melee_attack_damage(monster_array[index]);
		random_crit = rand() % 101;
		if(random_crit > 100 - (CRIT_CHANCE * 100)) {
			damage *= 3;
			printf("Console: Monster %d inflicted %d CRITICAL Damage.\n", index, damage);
		}
		else
			printf("Console: Monster %d inflicted %d Damage.\n", index, damage);

		level->player.Hp -= damage;
		if(player_is_dead(level->player))
			return 1;
	}

	free(monster_array);
	return 1;
}

int player_melee_attack_monster(Level *level, int x, int y) {
	int damage, random_crit;

	if(level->floor[x][y].type != MONSTER)
		return 0;
	damage = player_melee_attack_damage(level->player);
	random_crit = rand() % 101;
	if(random_crit > 100 - (CRIT_CHANCE * 100)) {
		damage *= 3;
		printf("Console: Player inflicted %d CRITICAL Melee Damage.\n", damage);
	}
	else
		printf("Console: Player inflicted %d Melee Damage.\n", damage);
	level->floor[x][y].monster.Hp -= damage;

	return 1;
}

int player_magic_attack_monster(Level *level, int x, int y) {
	int damage, random_crit;

	if(level->floor[x][y].type != MONSTER)
		return 0;
	damage = player_magic_attack_damage(&(level->player));
	random_crit = rand() % 101;
	if(random_crit > 100 - (CRIT_CHANCE * 100)) {
		damage *= 3;
		printf("Console: Player inflicted %d CRITICAL Magic Damage.\n", damage);
	}
	else
		printf("Console: Player inflicted %d Magic Damage.\n", damage);
	level->floor[x][y].monster.Hp -= damage;

	return 1;
}

void player_action_ascii(Level *level) {
	char move_key, confirm_key;
	int x, y, monster_x, monster_y, treasure_x, treasure_y;

	scanf("%c", &move_key);
	switch(move_key) {
		case 'z': move(&(level->player), NORTH, HEIGHT, WIDTH); break;
		case 'd': move(&(level->player), EAST, HEIGHT, WIDTH); break;
		case 's': move(&(level->player), SOUTH, HEIGHT, WIDTH); break;
		case 'q': move(&(level->player), WEST, HEIGHT, WIDTH); break;
		case 'a': 
			printf("X: ");
			scanf("%d", &x);
			printf("Y: ");
			scanf("%d", &y);
			monster_x = level->player.x + x;
			monster_y = level->player.y + y;
			if(monsters_in_range(*level)) {
				if(player_melee_attack_monster(level, monster_y, monster_x)) {
					if(monster_is_dead(level->floor[monster_y][monster_x].monster)) {
						printf("Console: Monster at position (%d,%d) has been slain.\n", monster_y, monster_x);
						add_exp(&(level->player), gained_exp(*level));
						level->floor[monster_y][monster_x].type = ROOM;
					}
				}
				else
					printf("Console: Melee Attack at position (%d,%d) is not allowed.\n", x, y);
			}
			sleep(1);
			break;
		case 'e': 
			printf("X: ");
			scanf("%d", &x);
			printf("Y: ");
			scanf("%d", &y);
			monster_x = level->player.x + x;
			monster_y = level->player.y + y;
			if(monsters_in_range(*level)) {
				if(player_magic_attack_monster(level, monster_y, monster_x)) {
					if(monster_is_dead(level->floor[monster_y][monster_x].monster)) {
						printf("Console: Monster at position (%d,%d) has been slain.\n", monster_y, monster_x);
						add_exp(&(level->player), gained_exp(*level));
						level->floor[monster_y][monster_x].type = ROOM;
					}
				}
				else
					printf("Console: Magic Attack at position (%d,%d) is not allowed.\n", x, y);
			}
			sleep(1);
			break;
		case 'f':
			printf("X: ");
			scanf("%d", &x);
			printf("Y: ");
			scanf("%d", &y);
			treasure_x = level->player.x + x;
			treasure_y = level->player.y + y;
			if(level->floor[treasure_y][treasure_x].type == TREASURE) {
				printf("Do you want to pick up: ");
				print_treasure(level->floor[treasure_y][treasure_x].treasure);
				printf("Y/N: ");
				scanf("%c", &confirm_key);
				if(confirm_key == 'y' || confirm_key == 'Y') {
					if(!inventory_is_full(level->inventory)) {
						if(level->floor[treasure_y][treasure_x].treasure.type == ITEM) {
							if(level->floor[treasure_y][treasure_x].treasure.item.type == ARMOR)
								level->player.Def -= equiped_armor(level->inventory);
							else if(level->floor[treasure_y][treasure_x].treasure.item.type == WEAPON)
								level->player.Atk -= equiped_weapon(level->inventory);
							else if(level->floor[treasure_y][treasure_x].treasure.item.type == WAND)
								level->player.Int -= equiped_wand(level->inventory);
							
							add_treasure(&(level->inventory), level->floor[treasure_y][treasure_x].treasure);
							printf("Console: Added ");
							print_treasure(level->floor[treasure_y][treasure_x].treasure);
							level->floor[treasure_y][treasure_x].type = ROOM;

							if(level->floor[treasure_y][treasure_x].treasure.item.type == ARMOR)
								level->player.Def += equiped_armor(level->inventory);
							else if(level->floor[treasure_y][treasure_x].treasure.item.type == WEAPON)
								level->player.Atk += equiped_weapon(level->inventory);
							else if(level->floor[treasure_y][treasure_x].treasure.item.type == WAND)
								level->player.Int += equiped_wand(level->inventory);
						}
					}
				}
				else if(confirm_key == 'n' || confirm_key == 'N')
					printf("Do nothing.\n");
				else
					printf("Wrong Key pressed.\n");
			}
			sleep(1);
			break;
		case 'i':
			print_inventory(level->inventory);
			sleep(1);
			break;
		case 'c':
			print_player(level->player);
			sleep(2);
			break;
	}
}