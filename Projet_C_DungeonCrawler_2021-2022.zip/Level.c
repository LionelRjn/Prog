/* Dos Santos Loïc */
/* Création : 20-10-2021 */
/* Dernière modification : 20-10-2021 */
#include "Level.h"

void init_empty_floor(Level *level) {
	int i, j;

	level->stage = 1;
	level->player = init_player(HEIGHT, WIDTH);
	level->inventory = init_inventory();
	for(i = 0; i < HEIGHT; i++) {
		for(j = 0; j < WIDTH; j++) {
			level->floor[i][j] = init_cell(ROOM, level->stage);
		}
	}

	for(j = 0; j < WIDTH; j++) {
		level->floor[0][j] = init_cell(WALL, level->stage);
		level->floor[HEIGHT - 1][j] = init_cell(WALL, level->stage);
	}
	for(i = 1; i < HEIGHT - 1; i++) {
		level->floor[i][0] = init_cell(WALL, level->stage);
		level->floor[i][WIDTH - 1] = init_cell(WALL, level->stage);
	}
}

void init_first_floor(Level *level) {
	int random_i, random_j, random_number_of_monster, random_number_of_treasure, k;

	init_empty_floor(level);

	do {
		random_i = rand() % HEIGHT;
		random_j = rand() % WIDTH;
	} while(level->floor[random_i][random_j].type != ROOM && level->player.x != random_j && level->player.y != random_i);
	level->floor[random_i][random_j] = init_cell(STAIR_DOWN, level->stage);

	random_number_of_monster = rand() % 5 + 6;

	for(k = 0; k < random_number_of_monster; k++) {
		do {
			random_i = rand() % HEIGHT;
			random_j = rand() % WIDTH;
		} while(level->floor[random_i][random_j].type != ROOM && level->player.x != random_j && level->player.y != random_i);
		level->floor[random_i][random_j] = init_cell(MONSTER, level->stage);
	}

	random_number_of_treasure = rand() % 3 + 4;

	for(k = 0; k < random_number_of_treasure; k++) {
		do {
			random_i = rand() % HEIGHT;
			random_j = rand() % WIDTH;
		} while(level->floor[random_i][random_j].type != ROOM && level->player.x != random_j && level->player.y != random_i);
		level->floor[random_i][random_j] = init_cell(TREASURE, level->stage);
	}
}

void print_floor_ascii(Level level) {
	int i, j;
	for(i = 0; i < HEIGHT; i++) {
		for(j = 0; j < WIDTH; j++) {
			if(level.player.x == j && level.player.y == i)
				printf("P");
			else
				print_cell_ascii(level.floor[i][j]);
		}
		printf("\n");
	}
}