/* Dos Santos Loïc */
/* Création : 12-10-2021 */
/* Dernière modification : 12-10-2021 */
#ifndef __MONSTER__H__
#define __MONSTER__H__
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MONSTER_HP 40
#define MONSTER_ATK 5

/* SubTypes of Monster. */
/*typedef enum {
	SKELETON,
	ZOMBIE
} MonsterType;*/

typedef struct {
	int Hp;
	int Atk;
} Monster;

/* Initializes a Monster with its number of HP returns the monster. */
Monster init_monster();

/* Print all useful informations about the Monster. */
void print_monster(Monster monster);

/* Print the lore about the Monster. */
/*void print_monster_description(Monster monster);*/

/* Calculate the melee attack damage of a Monster and returns the damage rolled value. */
int monster_melee_attack_damage(Monster monster);

/* Return 1 if the Monster's Hp are equals or lower than 0,
 * Return 0 otherwise. */
int monster_is_dead(Monster monster);

#endif