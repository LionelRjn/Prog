/* Dos Santos Loïc */
/* Création : 30-10-2021 */
/* Dernière modification : 30-10-2021 */
#include "Potion.h"

Potion init_potion() {
	Potion potion;
	int random_number;

	random_number = rand() % 5;
	switch(random_number) {
		case 0: potion.type = HEALING_POTION; break;
		case 1: potion.type = MANA_POTION; break;
		case 2: potion.type = REGEN_POTION; break;
		case 3: potion.type = ACCURACY_POTION; break;
		case 4: potion.type = WISDOM_POTION; break;
	}

	return potion;
}

void print_potion(Potion potion) {
	switch(potion.type) {
		case HEALING_POTION: printf("Heals 10%% of Max HP\n"); break;
		case MANA_POTION: printf("Heals 10%% of Max MP\n"); break;
		case REGEN_POTION: printf("Heals 20 HP and 10 MP per turn for 30 turns\n"); break;
		case ACCURACY_POTION: printf("Increase crit chance by 5-15%% for 30 turns\n"); break;
		case WISDOM_POTION: printf("Increase Exp gain by 30%% for 30 turns\n"); break;
	}
}