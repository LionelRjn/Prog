/* Dos Santos Loïc */
/* Création : 30-10-2021 */
/* Dernière modification : 30-10-2021 */
#ifndef __ITEM__H__
#define __ITEM__H__
#include <stdio.h>
#include <stdlib.h>

typedef enum {
	ARMOR,
	WEAPON,
	WAND
} ItemType;

typedef struct {
	ItemType type;
	int quality;
} Item;

/* Initializes an Item with a random type and returns it. */
Item init_item(int quality);

/* Print all useful informations about the Item. */
void print_item(Item item);

#endif