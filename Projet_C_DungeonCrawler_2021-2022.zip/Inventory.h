/* Dos Santos Loïc */
/* Création : 15-11-2021 */
/* Dernière modification : 15-11-2021 */
#ifndef __INVENTORY__H__
#define __INVENTORY__H__
#include <stdio.h>
#include <stdlib.h>
#include "Treasure.h"

#define MAX_SLOTS 12

typedef struct {
	int slots_occupied;
	Treasure slots[MAX_SLOTS];
} Inventory;

/* Initializes an Inventory and returns it. */
Inventory init_inventory();

/* Print all the Treasures in the Inventory. */
void print_inventory(Inventory inventory);

/* Returns 1 if the Inventory is full,
 * Returns 0 otherwise. */
int inventory_is_full(Inventory inventory);

/* Returns the quality of the best Armor in the Inventory. */
int equiped_armor(Inventory inventory);

/* Returns the quality of the best Weapon in the Inventory. */
int equiped_weapon(Inventory inventory);

/* Returns the quality of the best Wand in the Inventory. */
int equiped_wand(Inventory inventory);

/* Adds the Treasure to the Inventory. */
void add_treasure(Inventory *inventory, Treasure treasure);

/* Removes a Treasure at the slot number slot_number from the Inventory.
 * Returns the Treasure removed. */
Treasure remove_treasure(Inventory *inventory, int slot_number);

#endif